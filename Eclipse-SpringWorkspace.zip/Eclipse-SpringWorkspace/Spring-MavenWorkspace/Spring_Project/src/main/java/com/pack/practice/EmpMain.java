package com.pack.practice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class EmpMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Emp.xml");
		   Employee myBean=(Employee) context.getBean("fidelitypay");
		  System.out.println("ID: "+ myBean.getId());
		  System.out.println("ID: "+ myBean.getName());
		  
		  System.out.println("Address "+myBean.getAddress().getCity());
	}

}
