package SpringCore;

public class Message {

	String greeting;
	
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

	public String getGreeting() {
		return greeting;
	}

}
