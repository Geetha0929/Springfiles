package SpringCore;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Core1 {

	public static void main(String[] args) {
		ApplicationContext  context =  new  FileSystemXmlApplicationContext("E:/First.xml");
		Message obj1=(Message)context.getBean("message");
		obj1.setGreeting("Hello");
		Message obj2=(Message)context.getBean("message");
		obj2.setGreeting("Hi");
	    String response1=obj1.getGreeting();
	    String response2=obj2.getGreeting();
	    System.out.println(response1);
	    System.out.println(response2);
	}

}
