package com.pack.address;

public class Employee {
    int id;
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	String name;
    Address address;
    public Employee(int ide,String nam, Address addr )
    {
    	id=ide;
    	name=nam;
    	address=addr;
    }
}
