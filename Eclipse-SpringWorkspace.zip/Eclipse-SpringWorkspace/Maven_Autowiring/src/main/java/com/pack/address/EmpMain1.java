package com.pack.address;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpMain1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("Emp.xml");
		  
		  Employee myBean=(Employee) context.getBean("Employee");
		  System.out.println("ID: "+myBean.getId());
		  System.out.println("Address "+myBean.getAddress().getCity());
	}


	}


